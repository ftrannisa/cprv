<?php $__env->startSection('content'); ?>
<div class="title m-l m-b-md">
            Report Page
    </div>
    <div  class="m-l"> 
    <table id="t01">
       
        <tr>
            <th>Time</th>
            <th>PIN</th> 
            <th>Product A</th>
            <th>Product B</th>
        </tr>
        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($data->createdAt); ?></td>
            <td><?php echo e($data->pin); ?></td>
            <td><?php echo e($data->productA); ?></td> 
            <td><?php echo e($data->productB); ?></td>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tr>
    </table>
       
    
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/fitri/cprv/resources/views/report.blade.php ENDPATH**/ ?>