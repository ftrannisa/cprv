
<div class="jumbotron-fluid text-center">
    <div class="container">
        <h1>Welcome to the Sample_Application</h1>
        <p class="lead">
            You can tell by their brake lights that they saw what was about to go down.
            Glad they decided to hit the brakes instead of the gas. Could've been much worse.
        </p>

    </div>

</div>
<?php /**PATH /home/fitri/cprv/resources/views/inc/showcase.blade.php ENDPATH**/ ?>